// UDP_Sender.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include "Packet.h"
#include "UDPHandler.h"
#include "FileHandler.h"

#define TARGET_IP   L"192.168.30.18"
#define TARGET_PORT 5555
#define LOCAL_PORT  8888

#define MAX_PACKET_LEN 1024
#define START_STRING "START"
#define END_STRING "END"

int main(int argc, char* argv[])
{
    //read parameter or get file from input
    const char* filename;
    std::string line;
    if (argc > 1) {
        filename = argv[1];
    }
    else {
        std::cout << "Enter path and name of file to send:" << std::endl;        
        std::getline(std::cin, line);
        filename = line.c_str();
    }

    //Open file
    printf("Opening file.\n");
    FileHandler fh = FileHandler(filename);

    //Initialize UDP
    printf("Creating socket.\n");
    UDPHandler udph = UDPHandler(TARGET_IP, TARGET_PORT, LOCAL_PORT);

    //Send header packet
    printf("Sending header.\n");
    Packet startPacket = Packet(MAX_PACKET_LEN);
    startPacket.append("START", strlen(START_STRING));
    const unsigned int filesize_big_endian = htonl(fh.get_filesize());
    startPacket.append((char*)&filesize_big_endian, sizeof(unsigned int));
    startPacket.append(fh.get_name(), strlen(fh.get_name())+1);
    udph.send_packet(startPacket);

    //Send file packets
    printf("Sending file.\n");
    const unsigned int max_payload_len = MAX_PACKET_LEN - sizeof(unsigned int);
    unsigned int next_size = fh.get_next_size(max_payload_len);
    while (next_size > 0U) {
        Packet p = Packet(MAX_PACKET_LEN);
        const unsigned int pos = htonl(fh.get_cur_pos());
        p.append((char*)&pos, sizeof(unsigned int));     
        p.append(fh.get_next(next_size), next_size);

        udph.send_packet(p);
        next_size = fh.get_next_size(max_payload_len);        
    }

    //Send terminating packet
    Packet endPacket = Packet(MAX_PACKET_LEN);
    endPacket.append(END_STRING, strlen(END_STRING));
    udph.send_packet(endPacket);
    printf("File sent.\n");

    printf("Press any key to end program...\n");
    getchar();
}
