#pragma once

#pragma comment(lib, "ws2_32.lib")
#include <SDKDDKVer.h>
#include <stdio.h>
#include <tchar.h>
#include <winsock2.h>
#include "ws2tcpip.h"
#include "Packet.h"

class UDPHandler
{
private:
	SOCKET socketS;
	sockaddr_in addrDest;


public:
	/**
	 * UDPHandler constructor.
	 * Initializes UDP protocol and creates socket
	 * 
	 * \param target_ip IP adress of target computer
	 * \param target_port Port on target computer
	 * \param local_port Port on this computer
	 */
	UDPHandler(PCWSTR target_ip, u_short target_port, u_short local_port);

	/**
	 * Closes socket.
	 */
	~UDPHandler();

	/**
	 * Sends the passed packet.
	 * 
	 * \param p packet to send
	 */
	void send_packet(Packet p);

};

