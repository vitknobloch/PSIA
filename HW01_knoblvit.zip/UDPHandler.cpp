#include "UDPHandler.h"


UDPHandler::UDPHandler(PCWSTR target_ip, u_short target_port, u_short local_port)
{
	//initialize winsock
	WSADATA wsaData;
	WSAStartup(MAKEWORD(2, 2), &wsaData);

	//add local address and port
	struct sockaddr_in local;
	local.sin_family = AF_INET;
	local.sin_port = htons(local_port);
	local.sin_addr.s_addr = INADDR_ANY;

	//create and bind socket
	socketS = socket(AF_INET, SOCK_DGRAM, 0);
	if (bind(socketS, (sockaddr*)&local, sizeof(local)) != 0) {
		printf("Binding error!\n");
		getchar();
		exit(-1);
	}

	//add target adress and port
	addrDest.sin_family = AF_INET;
	addrDest.sin_port = htons(target_port);
	InetPton(AF_INET, target_ip, &addrDest.sin_addr.s_addr);
}

UDPHandler::~UDPHandler()
{
	closesocket(socketS);
}

void UDPHandler::send_packet(Packet p)
{
	const int ret = sendto(socketS, p.get_buffer(), p.get_size(), 0, (sockaddr*)&addrDest, sizeof(addrDest));
}
