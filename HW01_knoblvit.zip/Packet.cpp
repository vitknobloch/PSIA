#include "Packet.h"
#include <string.h>

Packet::Packet(unsigned int max_lenght)
{
	capacity = max_lenght;
	buffer = new char[max_lenght];
	size = 0;
}

Packet::~Packet() {
	
}

bool Packet::append(const char* data, const unsigned int len)
{
	//check if there's room for the data
	if (len > free_capacity()) {
		return false;
	}

	//copy data to packet buffer
	memcpy(&buffer[size], data, len);
	size += len;
}

unsigned int Packet::free_capacity()
{
	return capacity - size;
}

const char* Packet::get_buffer()
{
	return buffer;
}

unsigned int Packet::get_size()
{
	return size;
}
