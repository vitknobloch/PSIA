#pragma once
class Packet
{
protected:
	char* buffer; //actual bytes of packet
	unsigned int capacity; //maximal size of packet
	unsigned int size; //current size of packet


public:
	/**
	 * Packet constructor.
	 * 
	 * \param max_lenght maximal size of packet
	 */
	Packet(unsigned int max_lenght);
	~Packet();
	
	/**
	 * Add data to packet if there is room for it.
	 * 
	 * \param data pointer to start of the data area to append
	 * \param len number of bytes to copy from data to packet
	 * \return true in case of success, false otherwise (data don't fit inside packet)
	 */
	bool append(const char *data, const unsigned int len);

	/**
	 * Calculate free capacity of packet.
	 * 
	 * \return unsigned int - number of bytes left free in packet
	 */
	unsigned int free_capacity();

	/**
	 * Buffer getter.
	 * 
	 * \return const char* - pointer to the packets buffer
	 */
	const char* get_buffer();

	/**
	 * Size getter.
	 * 
	 * \return unsigned int - current size of the packet
	 */
	unsigned int get_size();

};

